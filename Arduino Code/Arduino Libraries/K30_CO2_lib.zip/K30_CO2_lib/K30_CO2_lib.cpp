/*

  Arduino Library for SenseAir CO2 Engine K30 STA sensor module
  Written by Aidan Bennett-Reilly for BRANZ NZ - 12/12/2016 

  ---

  The MIT License (MIT)

  Copyright (c) 2016 BRANZ NZ

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
  THE SOFTWARE.

*/

#include <Wire.h>
#include "K30_CO2_lib.h"
#include <Arduino.h>


K30_CO2_lib::K30_CO2_lib()
{
} 

bool K30_CO2_lib::begin(uint8_t address) {
	_address = address;
	Wire.begin();
	if(0 == readCO2()){
		return false;
	}
	return true;
}


/* uint8_t[] readData(uint8_t numBytes){
	uint8_t buffer[numBytes];
	uint8_t sum =0; //Checksum Byte
	Wire.requestFrom(_address, numBytes);
	
	for (uint8_t index = 0; index < numBytes; index++) {
		buffer[index] = Wire.read();
		
		
    }
	for(uint8_t index=0; index < numbytes-1;index++){
		sum = sum + buffer[index];
	}
	
	if (sum == buffer[numBytes-1])
	{
		return buffer;
	}
	
} */



/* float K30_CO2_lib::readT() {
  return readTemperature();
  } */

uint16_t K30_CO2_lib::readCO2() {

	uint8_t buffer[4] = {0, 0, 0, 0};
	uint8_t retryCounter;
	uint16_t co2_value = 0;
	byte sum;

  while (retryCounter < retryCount) { //allow three attempts before stopping
	if (retryCounter >0){
		delay(20);
	}

    Wire.beginTransmission(_address);
    Wire.write(0x22);
    Wire.write(0x00);
    Wire.write(0x08);
    Wire.write(0x2A);
    Wire.endTransmission();

    delay(20);

    Wire.requestFrom(_address, (uint8_t)4);

    for (uint8_t index = 0; index < 4; index++) {
		buffer[index] = Wire.read();
		

    }
	

    if ( (buffer[0] & (1 << 0)) && retryCounter >= retryCount) {
		//command was NOT executed correctly
		
		
		return 0;

    }
    else {
		sum = 0; //Checksum Byte
		sum = buffer[0] + buffer[1] + buffer[2]; // add bytes for checksum, allows overflow
		if (sum == buffer[3])
		{
			// Checksum matches Data
			//the extra && 0xFF ensures values from expanding to 16 bits from 8 bits are zero
			co2_value |= buffer[1] & 0xFF;
			co2_value = co2_value << 8;
			co2_value |= buffer[2] & 0xFF;
			return co2_value;

      }

    }



    retryCounter++;
	
  }
  
  for (uint8_t index = 0; index < 4; index++) {
			
		Serial.print(buffer[index] );
	}



  return 7;  //zero should be an invalid value with the intended use of the sensor
}

//this mebthod may not work - experimental!
void K30_CO2_lib::backgroundCalibrate() {
	
	Wire.beginTransmission(_address);
    Wire.write(0x12);
    Wire.write(0x00);
    Wire.write(0x67);
	Wire.write(0x7C);
	Wire.write(0x06);
    Wire.write(0xFB);
    Wire.endTransmission();
	
}


/* int K30_CO2_lib::getErrorStatus(){
	
	
	
	
} */

/* int K30_CO2_lib::disableABC(bool disabled){
	
	if(disabled){
		
	}
	else{
		
		
	}
	
	
}  */






/* void K30_CO2_lib::zeroCalibrate() {
	
	Wire.beginTransmission(_address);
    Wire.write(0x12);
    Wire.write(0x00);
    Wire.write(0x67);
	Wire.write(0x7C);
	Wire.write(0x07);
    Wire.write(0xFB);
    Wire.endTransmission();
	
} */


